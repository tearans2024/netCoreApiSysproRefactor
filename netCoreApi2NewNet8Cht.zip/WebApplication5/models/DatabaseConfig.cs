﻿namespace netCoreApiSysproRefactor.models
{
    public class DatabaseConfig
    {
        public string ConnectionString { get; set; } = string.Empty;
    }
}
