using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.ResponseCompression;
using System.IO.Compression;
using Serilog;
using AspNetCoreRateLimit;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Caching.StackExchangeRedis;
using System.Collections.Generic;

var builder = WebApplication.CreateBuilder(args);

// ✅ Konfigurasi Serilog untuk logging
Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .WriteTo.File("logs/log.txt", rollingInterval: RollingInterval.Day)
    .CreateLogger();
builder.Host.UseSerilog(); // Menggunakan Serilog sebagai sistem logging aplikasi

// ✅ Ambil konfigurasi dari appsettings.json

var configuration = builder.Configuration;
var dbConnection = configuration.GetSection("DatabaseSettings")["ConnectionString"];

if (string.IsNullOrWhiteSpace(dbConnection)) // Pastikan koneksi database tidak kosong
{
    Log.Fatal("Connection string tidak ditemukan di appsettings.json!");
    throw new InvalidOperationException("Connection string tidak ditemukan di appsettings.json!");
}

// ✅ Tambahkan DbContext untuk PostgreSQL dengan Retry Policy (untuk menangani kegagalan koneksi sementara)
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(dbConnection, npgsqlOptions =>
    {
        npgsqlOptions.EnableRetryOnFailure(); // Coba ulang koneksi jika gagal sementara
    }));

// ✅ Konfigurasi Redis atau Memory Cache berdasarkan setting dari appsettings.json
bool useRedis = configuration.GetValue<bool>("CacheSettings:UseRedis");
if (useRedis)
{
    var redisConn = configuration["CacheSettings:RedisConnection"];
    if (string.IsNullOrWhiteSpace(redisConn))
    {
        Log.Fatal("Redis diaktifkan, tetapi koneksi Redis tidak ditemukan di appsettings.json!");
        throw new InvalidOperationException("Redis diaktifkan, tetapi koneksi Redis tidak ditemukan!");
    }

    // Gunakan Redis sebagai cache jika Redis diaktifkan
    builder.Services.AddStackExchangeRedisCache(options =>
    {
        options.Configuration = redisConn;
        options.InstanceName = configuration["CacheSettings:InstanceName"];
    });
}
else
{
    // Gunakan Memory Cache jika Redis tidak diaktifkan
    builder.Services.AddMemoryCache();
    builder.Services.AddSingleton<IDistributedCache, MemoryDistributedCache>();
}

// ✅ Middleware Response Compression (Brotli & Gzip)
builder.Services.Configure<BrotliCompressionProviderOptions>(options =>
{
    options.Level = CompressionLevel.Optimal; // Gunakan level kompresi optimal
});

builder.Services.Configure<GzipCompressionProviderOptions>(options =>
{
    options.Level = CompressionLevel.Optimal; // Gunakan level kompresi optimal
});

builder.Services.AddResponseCompression(options =>
{
    options.EnableForHttps = true; // Pastikan kompresi hanya digunakan pada HTTPS
    options.Providers.Add<BrotliCompressionProvider>(); // Tambahkan Brotli sebagai metode kompresi utama
    options.Providers.Add<GzipCompressionProvider>(); // Tambahkan Gzip sebagai cadangan jika Brotli tidak tersedia
});

// ✅ Konfigurasi Swagger untuk dokumentasi API
bool enableSwagger = false;
if (configuration.GetSection("EnableSwagger").Exists()) // Pastikan Swagger diaktifkan di konfigurasi
{
    enableSwagger = configuration.GetValue<bool>("EnableSwagger");
}

if (enableSwagger)
{
    builder.Services.AddEndpointsApiExplorer(); // Aktifkan eksplorasi endpoint API
    builder.Services.AddSwaggerGen(); // Tambahkan Swagger UI untuk dokumentasi API
}

// ✅ Konfigurasi CORS (Cross-Origin Resource Sharing)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
        policy.AllowAnyOrigin() // Izinkan akses dari semua domain
            .AllowAnyMethod() // Izinkan semua metode HTTP (GET, POST, PUT, DELETE, dll.)
            .AllowAnyHeader()); // Izinkan semua header
});

// ✅ Middleware Rate Limiting untuk membatasi jumlah request per IP
builder.Services.AddOptions();
builder.Services.AddMemoryCache();

// ✅ Konfigurasi Rate Limiting berdasarkan `appsettings.json`
builder.Services.Configure<IpRateLimitOptions>(configuration.GetSection("IpRateLimiting"));
builder.Services.Configure<IpRateLimitPolicies>(configuration.GetSection("IpRateLimitPolicies"));

// ✅ Tambahkan penyimpanan Rate Limiting dalam memory
builder.Services.AddSingleton<IRateLimitConfiguration, RateLimitConfiguration>();
builder.Services.AddSingleton<IIpPolicyStore, MemoryCacheIpPolicyStore>();
builder.Services.AddSingleton<IRateLimitCounterStore, MemoryCacheRateLimitCounterStore>();

// ✅ Gunakan penyimpanan In-Memory sebelum AddIpRateLimiting()
builder.Services.AddInMemoryRateLimiting();
builder.Services.AddIpRateLimiting(); // Aktifkan Rate Limiting

// ✅ Tambahkan Authentication & Authorization menggunakan JWT

var jwtKey = configuration["Jwt:Key"];
if (string.IsNullOrEmpty(jwtKey)) // Pastikan kunci JWT tidak kosong
{
    Log.Fatal("JWT Key tidak ditemukan di appsettings.json!");
    throw new InvalidOperationException("JWT Key tidak ditemukan di appsettings.json!");
}

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = configuration["Jwt:Issuer"], // Ambil Issuer dari appsettings.json
            ValidAudience = configuration["Jwt:Audience"], // Ambil Audience dari appsettings.json
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)) // Gunakan kunci JWT yang telah dikonfigurasi
        };
    });

builder.Services.AddAuthorization(); // Tambahkan Authorization Service
builder.Services.AddControllers(); // Tambahkan Controller Service

var app = builder.Build(); // Bangun aplikasi

// ✅ Middleware
app.UseHttpsRedirection(); // Redirect semua request HTTP ke HTTPS
app.UseAuthentication(); // Aktifkan Authentication Middleware (JWT)
app.UseAuthorization(); // Aktifkan Authorization Middleware
app.UseSerilogRequestLogging(); // Logging setiap request masuk
app.UseCors("AllowAll"); // Aktifkan CORS dengan kebijakan yang telah dikonfigurasi
app.UseResponseCompression(); // Aktifkan kompresi respons API
app.UseIpRateLimiting(); // Aktifkan Rate Limiting Middleware

// ✅ Swagger UI untuk dokumentasi API
if (enableSwagger)
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapControllers(); // Map Controller untuk menangani request API

// ✅ Menjalankan aplikasi dengan error handling
try
{
    Log.Information("Aplikasi berjalan..."); // Log informasi bahwa aplikasi sedang berjalan
    app.Run(); // Jalankan aplikasi
}
catch (Exception ex)
{
    Log.Fatal(ex, "Aplikasi gagal berjalan!"); // Log error jika aplikasi gagal berjalan
}
finally
{
    Log.CloseAndFlush(); // Tutup dan flush semua log sebelum aplikasi berhenti
}
